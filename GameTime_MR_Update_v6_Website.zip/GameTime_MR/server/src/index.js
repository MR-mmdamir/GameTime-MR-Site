import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Server } from 'socket.io';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

const prisma = new PrismaClient();
const app = express();
const server = http.createServer(app);
const origins = (process.env.CLIENT_ORIGIN || 'http://localhost:8081').split(',').map(x => x.trim()).filter(Boolean);
const originAllowed = (origin, callback) => {
  if (!origin || origins.includes(origin)) return callback(null, true);
  return callback(new Error('Origin is not allowed by CORS'));
};
const io = new Server(server, { cors: { origin: originAllowed, credentials: true } });

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: originAllowed, credentials: true }));
app.use(express.json({ limit: '32kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 100, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false }));

const sign = user => jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '14d' });
async function auth(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!req.user) return res.status(401).json({ error: 'حساب کاربری پیدا نشد' });
    next();
  } catch { return res.status(401).json({ error: 'ابتدا وارد حساب شوید' }); }
}
const admin = (req, res, next) => req.user?.isAdmin ? next() : res.status(403).json({ error: 'دسترسی مدیر لازم است' });
const cleanUser = u => ({ id:u.id, username:u.username, email:u.email, isAdmin:u.isAdmin, timeBalance:u.timeBalance||0, avatarId:u.avatarId||'default', chatTheme:u.chatTheme||'default' });

app.get('/api/health', (_, res) => res.json({ ok:true, service:'GameTime MR API' }));

app.post('/api/auth/register', async (req,res) => {
  const parsed = z.object({ username:z.string().min(3).max(24).regex(/^[a-zA-Z0-9_]+$/), email:z.string().email(), password:z.string().min(8).max(72) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error:'نام کاربری، ایمیل یا گذرواژه معتبر نیست' });
  const { username,email,password } = parsed.data;
  try {
    const user = await prisma.user.create({ data:{ username,email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12) } });
    res.status(201).json({ token:sign(user), user:cleanUser(user) });
  } catch { res.status(409).json({ error:'ایمیل یا نام کاربری قبلاً ثبت شده است' }); }
});
app.post('/api/auth/login', async (req,res) => {
  const parsed = z.object({ email:z.string().email(), password:z.string().min(1) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error:'اطلاعات ورود نامعتبر است' });
  const user = await prisma.user.findUnique({ where:{ email:parsed.data.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(parsed.data.password,user.passwordHash))) return res.status(401).json({ error:'ایمیل یا گذرواژه اشتباه است' });
  res.json({ token:sign(user), user:cleanUser(user) });
});
app.get('/api/me', auth, (req,res) => res.json({ user:cleanUser(req.user) }));

app.post('/api/sessions/start', auth, async (req,res) => {
  const active = await prisma.playSession.findFirst({ where:{ userId:req.user.id, endedAt:null } });
  if (active) return res.status(409).json({ error:'یک تایمر فعال دارید', session:active });
  const session = await prisma.playSession.create({ data:{ userId:req.user.id } });
  io.emit('leaderboard:changed');
  res.status(201).json({ session });
});
app.post('/api/sessions/stop', auth, async (req,res) => {
  const active = await prisma.playSession.findFirst({ where:{ userId:req.user.id, endedAt:null }, orderBy:{ startedAt:'desc' } });
  if (!active) return res.status(404).json({ error:'تایمر فعالی پیدا نشد' });
  const endedAt = new Date();
  const session = await prisma.playSession.update({ where:{ id:active.id }, data:{ endedAt } });
  io.emit('leaderboard:changed');
  res.json({ session, durationSeconds:Math.max(0,Math.floor((endedAt-active.startedAt)/1000)) });
});
app.post('/api/sessions/sync', auth, async (req,res) => {
  const p=z.object({sessions:z.array(z.object({clientId:z.string().min(1).max(100),startedAt:z.string().datetime(),endedAt:z.string().datetime()})).max(50)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'اطلاعات جلسات معتبر نیست'});
  const valid=p.data.sessions.filter(x=>new Date(x.endedAt)>new Date(x.startedAt) && (new Date(x.endedAt)-new Date(x.startedAt))<=24*60*60*1000);
  await prisma.playSession.createMany({data:valid.map(x=>({userId:req.user.id,clientId:x.clientId,startedAt:new Date(x.startedAt),endedAt:new Date(x.endedAt)})),skipDuplicates:true});
  io.emit('leaderboard:changed');
  res.json({synced:valid.length});
});
app.get('/api/sessions/active', auth, async (req,res) => {
  const session = await prisma.playSession.findFirst({ where:{ userId:req.user.id, endedAt:null }, orderBy:{ startedAt:'desc' } });
  res.json({ session });
});

async function totalsSince(since) {
  const now = Date.now();
  const sessions = await prisma.playSession.findMany({
    where: { startedAt: { lt: new Date(now) }, OR: [{ endedAt: null }, { endedAt: { gt: since } }] },
    include: { user: { select: { id: true, username: true } } }
  });
  const totals = new Map();
  for (const s of sessions) {
    const start = Math.max(s.startedAt.getTime(), since.getTime());
    const end = Math.min(s.endedAt ? s.endedAt.getTime() : now, now);
    const seconds = Math.max(0, Math.floor((end - start) / 1000));
    if (!seconds) continue;
    if (!totals.has(s.userId)) totals.set(s.userId, { user: s.user, seconds: 0 });
    totals.get(s.userId).seconds += seconds;
  }
  return [...totals.values()].sort((a,b)=>b.seconds-a.seconds).slice(0,100);
}
app.get('/api/stats/me', auth, async (req,res) => {
  const day = new Date(); day.setHours(0,0,0,0);
  const week = new Date(day); week.setDate(week.getDate()-6);
  const sessions = await prisma.playSession.findMany({where:{userId:req.user.id,endedAt:{not:null}}});
  const sumSince = since => sessions.filter(x=>x.startedAt>=since).reduce((n,x)=>n+Math.max(0,Math.floor((x.endedAt-x.startedAt)/1000)),0);
  const totalSeconds = sessions.reduce((n,x)=>n+Math.max(0,Math.floor((x.endedAt-x.startedAt)/1000)),0);
  res.json({ todaySeconds:sumSince(day), weekSeconds:sumSince(week), totalSeconds });
});
app.get('/api/leaderboard', async (req,res) => {
  const period = req.query.period === 'week' ? 'week' : 'day';
  const since = new Date(); since.setHours(0,0,0,0);
  if (period==='week') since.setDate(since.getDate()-6);
  res.json({ period, entries:await totalsSince(since) });
});

app.post('/api/suggestions', auth, async (req,res) => {
  const p=z.object({ title:z.string().min(4).max(100), body:z.string().min(8).max(2000) }).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'عنوان یا متن پیشنهاد معتبر نیست'});
  const item=await prisma.suggestion.create({data:{...p.data,userId:req.user.id}});
  res.status(201).json({suggestion:item});
});
app.get('/api/suggestions', async (_,res) => {
  const suggestions=await prisma.suggestion.findMany({where:{status:{not:'HIDDEN'}},orderBy:[{votes:'desc'},{createdAt:'desc'}],take:100,include:{user:{select:{username:true}}}});
  res.json({suggestions});
});
app.post('/api/suggestions/:id/vote', auth, async (req,res) => {
  const item=await prisma.suggestion.update({where:{id:req.params.id},data:{votes:{increment:1}}});
  res.json({suggestion:item});
});
app.post('/api/support', auth, async (req,res) => {
  const p=z.object({subject:z.string().min(4).max(120),body:z.string().min(2).max(3000)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'متن پیام معتبر نیست'});
  const ticket=await prisma.supportTicket.create({data:{userId:req.user.id,subject:p.data.subject,messages:{create:{sender:'USER',body:p.data.body}}},include:{messages:true}});
  res.status(201).json({ticket});
});
app.get('/api/support', auth, async (req,res) => {
  const tickets=await prisma.supportTicket.findMany({where:{userId:req.user.id},orderBy:{updatedAt:'desc'},include:{messages:true}});
  res.json({tickets});
});
app.post('/api/support/:id/messages', auth, async (req,res) => {
  const p=z.object({body:z.string().min(1).max(3000)}).safeParse(req.body);
  const ticket=await prisma.supportTicket.findFirst({where:{id:req.params.id,userId:req.user.id}});
  if(!ticket || !p.success) return res.status(404).json({error:'درخواست پیدا نشد'});
  const message=await prisma.supportMessage.create({data:{ticketId:ticket.id,sender:'USER',body:p.data.body}});
  await prisma.supportTicket.update({where:{id:ticket.id},data:{updatedAt:new Date()}});
  res.status(201).json({message});
});

// Social, daily rewards and avatar shop. Direct messages are limited to accepted friends.
const avatarCatalog = [
  { id:'pixel', name:'پیکسل', price:25, symbol:'▦' },
  { id:'comet', name:'دنباله‌دار', price:50, symbol:'☄' },
  { id:'crown', name:'تاج', price:100, symbol:'♛' },
  { id:'dragon', name:'اژدها', price:180, symbol:'♜' }
];
const chatThemeCatalog = [
  { id:'violet', name:'بنفش نئونی', price:20, color:'#8B5CF6' },
  { id:'ocean', name:'اقیانوسی', price:35, color:'#0EA5E9' },
  { id:'ember', name:'شعله‌ای', price:45, color:'#F97316' }
];
const dailyWords = ['کهکشان','سرعت','قهرمان','پیکسل','ماجراجو','انرژی','رقابت','تمرکز','زمان','ستاره','افق','مهارت','برد','مرحله'];
const dayKeyNow = () => new Date().toISOString().slice(0,10);
const dailyWordNow = () => {
  const day = Math.floor(Date.now()/86400000);
  return dailyWords[(day * 17 + 11) % dailyWords.length];
};
async function areFriends(a,b) {
  return !!(await prisma.friendship.findFirst({where:{OR:[{userAId:a,userBId:b},{userAId:b,userBId:a}]}}));
}
app.get('/api/social/search', auth, async (req,res) => {
  const q=String(req.query.q||'').trim();
  if(q.length<2) return res.json({users:[]});
  const users=await prisma.user.findMany({where:{username:{contains:q,mode:'insensitive'},id:{not:req.user.id}},select:{id:true,username:true,avatarId:true},take:15,orderBy:{username:'asc'}});
  res.json({users});
});
app.get('/api/social/friends', auth, async (req,res) => {
  const rows=await prisma.friendship.findMany({where:{OR:[{userAId:req.user.id},{userBId:req.user.id}]},include:{userA:{select:{id:true,username:true,avatarId:true}},userB:{select:{id:true,username:true,avatarId:true}}}});
  res.json({friends:rows.map(x=>x.userAId===req.user.id?x.userB:x.userA)});
});
app.get('/api/social/requests', auth, async (req,res) => {
  const [incoming,outgoing]=await Promise.all([
    prisma.friendRequest.findMany({where:{receiverId:req.user.id,status:'PENDING'},include:{sender:{select:{id:true,username:true}}},orderBy:{createdAt:'desc'}}),
    prisma.friendRequest.findMany({where:{senderId:req.user.id,status:'PENDING'},include:{receiver:{select:{id:true,username:true}}},orderBy:{createdAt:'desc'}})
  ]);
  res.json({incoming,outgoing});
});
app.post('/api/social/requests', auth, async (req,res) => {
  const p=z.object({userId:z.string().min(1)}).safeParse(req.body);
  if(!p.success || p.data.userId===req.user.id) return res.status(400).json({error:'کاربر مقصد معتبر نیست'});
  const target=await prisma.user.findUnique({where:{id:p.data.userId}});
  if(!target) return res.status(404).json({error:'کاربر پیدا نشد'});
  if(await areFriends(req.user.id,target.id)) return res.status(409).json({error:'این کاربر از قبل دوست شماست'});
  try {
    const request=await prisma.friendRequest.upsert({where:{senderId_receiverId:{senderId:req.user.id,receiverId:target.id}},create:{senderId:req.user.id,receiverId:target.id},update:{status:'PENDING',createdAt:new Date()}});
    res.status(201).json({request});
  } catch { res.status(409).json({error:'درخواست دوستی قبلاً ارسال شده است'}); }
});
app.post('/api/social/requests/:id/respond', auth, async (req,res) => {
  const p=z.object({accept:z.boolean()}).safeParse(req.body);
  const request=await prisma.friendRequest.findFirst({where:{id:req.params.id,receiverId:req.user.id,status:'PENDING'}});
  if(!p.success || !request) return res.status(404).json({error:'درخواست پیدا نشد'});
  if(p.data.accept) {
    await prisma.$transaction([
      prisma.friendship.create({data:{userAId:request.senderId,userBId:request.receiverId}}),
      prisma.friendRequest.update({where:{id:request.id},data:{status:'ACCEPTED'}})
    ]);
  } else await prisma.friendRequest.update({where:{id:request.id},data:{status:'DECLINED'}});
  res.json({ok:true});
});
app.get('/api/social/messages/:userId', auth, async (req,res) => {
  if(!(await areFriends(req.user.id,req.params.userId))) return res.status(403).json({error:'پیام خصوصی فقط بین دوستان فعال است'});
  const messages=await prisma.directMessage.findMany({where:{OR:[{senderId:req.user.id,receiverId:req.params.userId},{senderId:req.params.userId,receiverId:req.user.id}]},orderBy:{createdAt:'asc'},take:100,include:{sender:{select:{username:true}}}});
  res.json({messages});
});
app.post('/api/social/messages/:userId', auth, async (req,res) => {
  const p=z.object({body:z.string().trim().min(1).max(1000)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'متن پیام معتبر نیست'});
  if(!(await areFriends(req.user.id,req.params.userId))) return res.status(403).json({error:'برای پیام خصوصی ابتدا باید دوست شوید'});
  const message=await prisma.directMessage.create({data:{senderId:req.user.id,receiverId:req.params.userId,body:p.data.body},include:{sender:{select:{username:true}}}});
  res.status(201).json({message});
});
app.get('/api/wallet', auth, async (req,res) => {
  const [user,transactions,owned]=await Promise.all([
    prisma.user.findUnique({where:{id:req.user.id},select:{timeBalance:true,avatarId:true,chatTheme:true}}),
    prisma.walletTransaction.findMany({where:{userId:req.user.id},orderBy:{createdAt:'desc'},take:20}),
    prisma.ownedAvatar.findMany({where:{userId:req.user.id},select:{avatarId:true}})
  ]);
  res.json({balance:user.timeBalance,avatarId:user.avatarId,chatTheme:user.chatTheme,ownedAvatars:['default',...owned.map(x=>x.avatarId).filter(x=>!x.startsWith('chat:'))],ownedChatThemes:['default',...owned.map(x=>x.avatarId).filter(x=>x.startsWith('chat:')).map(x=>x.slice(5))],catalog:avatarCatalog,chatThemes:chatThemeCatalog,transactions});
});
app.get('/api/daily-word', auth, async (req,res) => {
  const dayKey=dayKeyNow();
  const claimed=await prisma.dailyClaim.findUnique({where:{userId_dayKey:{userId:req.user.id,dayKey}}});
  res.json({word:dailyWordNow(),dayKey,reward:10,claimed:!!claimed});
});
app.post('/api/daily-word/claim', auth, async (req,res) => {
  const p=z.object({word:z.string().trim().min(2).max(40)}).safeParse(req.body);
  if(!p.success || p.data.word!==dailyWordNow()) return res.status(400).json({error:'کلمه امروز درست نیست'});
  const dayKey=dayKeyNow();
  try {
    await prisma.$transaction(async tx=>{
      await tx.dailyClaim.create({data:{userId:req.user.id,dayKey}});
      await tx.user.update({where:{id:req.user.id},data:{timeBalance:{increment:10}}});
      await tx.walletTransaction.create({data:{userId:req.user.id,amount:10,reason:'daily-word',ref:`daily-word:${dayKey}`}});
    });
    const user=await prisma.user.findUnique({where:{id:req.user.id},select:{timeBalance:true}});
    res.json({ok:true,reward:10,balance:user.timeBalance});
  } catch { res.status(409).json({error:'پاداش امروز قبلاً دریافت شده است'}); }
});
app.post('/api/shop/avatar', auth, async (req,res) => {
  const p=z.object({avatarId:z.string().min(1).max(30)}).safeParse(req.body);
  const item=avatarCatalog.find(x=>x.id===p.data?.avatarId);
  if(!p.success || !item) return res.status(400).json({error:'آواتار معتبر نیست'});
  try {
    await prisma.$transaction(async tx=>{
      const owned=await tx.ownedAvatar.findUnique({where:{userId_avatarId:{userId:req.user.id,avatarId:item.id}}});
      if(owned) throw new Error('OWNED');
      const user=await tx.user.findUnique({where:{id:req.user.id},select:{timeBalance:true}});
      if(!user || user.timeBalance<item.price) throw new Error('FUNDS');
      await tx.user.update({where:{id:req.user.id},data:{timeBalance:{decrement:item.price},avatarId:item.id}});
      await tx.ownedAvatar.create({data:{userId:req.user.id,avatarId:item.id}});
      await tx.walletTransaction.create({data:{userId:req.user.id,amount:-item.price,reason:'avatar-purchase',ref:`avatar:${item.id}`}});
    });
    const user=await prisma.user.findUnique({where:{id:req.user.id},select:{timeBalance:true,avatarId:true}});
    res.json({ok:true,...user});
  } catch(e) {
    if(e.message==='OWNED') return res.status(409).json({error:'این آواتار را قبلاً خریده‌اید'});
    if(e.message==='FUNDS') return res.status(400).json({error:'TIME کافی ندارید'});
    return res.status(409).json({error:'خرید انجام نشد'});
  }
});
app.post('/api/shop/chat-theme', auth, async (req,res) => {
  const p=z.object({themeId:z.string().min(1).max(30)}).safeParse(req.body);
  const item=chatThemeCatalog.find(x=>x.id===p.data?.themeId);
  if(!p.success || !item) return res.status(400).json({error:'تم گفت‌وگو معتبر نیست'});
  try {
    await prisma.$transaction(async tx=>{
      const key='chat:'+item.id;
      const owned=await tx.ownedAvatar.findUnique({where:{userId_avatarId:{userId:req.user.id,avatarId:key}}});
      if(owned) throw new Error('OWNED');
      const user=await tx.user.findUnique({where:{id:req.user.id},select:{timeBalance:true}});
      if(!user || user.timeBalance<item.price) throw new Error('FUNDS');
      await tx.user.update({where:{id:req.user.id},data:{timeBalance:{decrement:item.price},chatTheme:item.id}});
      await tx.ownedAvatar.create({data:{userId:req.user.id,avatarId:key}});
      await tx.walletTransaction.create({data:{userId:req.user.id,amount:-item.price,reason:'chat-theme-purchase',ref:'chat-theme:'+item.id}});
    });
    const user=await prisma.user.findUnique({where:{id:req.user.id},select:{timeBalance:true,chatTheme:true}});
    res.json({ok:true,...user});
  } catch(e) {
    if(e.message==='OWNED') return res.status(409).json({error:'این تم را قبلاً خریده‌اید'});
    if(e.message==='FUNDS') return res.status(400).json({error:'TIME کافی ندارید'});
    return res.status(409).json({error:'خرید تم انجام نشد'});
  }
});
app.post('/api/shop/chat-theme/equip', auth, async (req,res) => {
  const p=z.object({themeId:z.string().min(1).max(30)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'تم معتبر نیست'});
  if(p.data.themeId!=='default' && !(await prisma.ownedAvatar.findUnique({where:{userId_avatarId:{userId:req.user.id,avatarId:'chat:'+p.data.themeId}}}))) return res.status(403).json({error:'این تم در مجموعه شما نیست'});
  const user=await prisma.user.update({where:{id:req.user.id},data:{chatTheme:p.data.themeId},select:{chatTheme:true,timeBalance:true}});
  res.json(user);
});
app.post('/api/shop/avatar/equip', auth, async (req,res) => {
  const p=z.object({avatarId:z.string().min(1).max(30)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'آواتار معتبر نیست'});
  if(p.data.avatarId!=='default' && !(await prisma.ownedAvatar.findUnique({where:{userId_avatarId:{userId:req.user.id,avatarId:p.data.avatarId}}}))) return res.status(403).json({error:'این آواتار در مجموعه شما نیست'});
  const user=await prisma.user.update({where:{id:req.user.id},data:{avatarId:p.data.avatarId},select:{avatarId:true,timeBalance:true}});
  res.json(user);
});

// Admin routes: create the first admin manually in the database after registration.
app.get('/api/admin/tickets', auth, admin, async (_,res) => res.json({tickets:await prisma.supportTicket.findMany({orderBy:{updatedAt:'asc'},include:{user:{select:{username:true,email:true}},messages:true}})}));
app.post('/api/admin/tickets/:id/reply', auth, admin, async (req,res) => {
  const p=z.object({body:z.string().min(1).max(3000)}).safeParse(req.body);
  const ticket=await prisma.supportTicket.findUnique({where:{id:req.params.id}});
  if(!ticket || !p.success) return res.status(404).json({error:'درخواست پیدا نشد'});
  const message=await prisma.supportMessage.create({data:{ticketId:ticket.id,sender:'SUPPORT',body:p.data.body}});
  await prisma.supportTicket.update({where:{id:ticket.id},data:{status:'ANSWERED'}});
  res.status(201).json({message});
});
app.patch('/api/admin/suggestions/:id/status', auth, admin, async (req,res) => {
  const p=z.object({status:z.enum(['NEW','APPROVED','HIDDEN'])}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:'وضعیت نامعتبر است'});
  const suggestion=await prisma.suggestion.update({where:{id:req.params.id},data:{status:p.data.status}});
  res.json({suggestion});
});
app.get('/api/admin/suggestions', auth, admin, async (_,res) => res.json({suggestions:await prisma.suggestion.findMany({orderBy:{createdAt:'desc'},include:{user:{select:{username:true}}}})}));

io.on('connection', socket => socket.emit('connected',{ok:true}));
const port=Number(process.env.PORT||4000);
app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'خطای داخلی سرور' : (err.message || 'درخواست نامعتبر است') });
});
server.listen(port,()=>console.log(`GameTime API listening on ${port}`));
