# Provisioning the first admin

Do not add a public admin-registration route. Register the intended owner account normally, then run this SQL against the production database using a trusted database console:

```sql
UPDATE "User" SET "isAdmin" = true WHERE email = 'owner@example.com';
```

Replace the email with the exact verified owner account. Protect the database console and never share admin credentials.
