// Set this to the public HTTPS URL of the GameTime MR API before publishing the site.
window.GAMETIME_API_URL = 'http://localhost:4000';
