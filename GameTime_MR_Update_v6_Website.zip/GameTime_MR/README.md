# GameTime — MR

Cross-platform starter project for Android + Web.

## Stack
- Expo + React Native + React Native Web (client)
- Node.js + Express + Socket.IO (API/realtime)
- PostgreSQL + Prisma (database)
- JWT authentication
- Light/Dark theme preference stored locally
- Offline-first local play timer with queued session sync when the API is reachable
- Friends, incoming friend requests and friend-only private messages
- TIME wallet, once-per-day word reward and avatar shop
- Separate responsive Persian web portal in `website/` for leaderboard, daily-word redemption, friends/chat and avatar shop
- Offline Pixel Tap and Memory Code mini-games (scores are cosmetic only; no cash value)

## What is included
- Registration and login
- Start/stop play sessions (server timestamps)
- Daily and weekly totals
- Public leaderboard
- Refined dashboard and gamer profile with daily, weekly and lifetime stats
- Suggestions and support tickets
- MR admin screen for support replies and suggestion moderation
- Realtime leaderboard refresh via Socket.IO
- Privacy-friendly defaults and no unnecessary device permissions

## Run locally

### Requirements
Node.js 20+, npm, PostgreSQL.

### 1) Backend
```bash
cd server
cp .env.example .env
# Set DATABASE_URL and JWT_SECRET in .env
npm install
npx prisma generate
npx prisma migrate deploy
npm run dev
```
API defaults to http://localhost:4000.

### 2) Client
In another terminal:
```bash
cd client
npm install
cp .env.example .env
# Set EXPO_PUBLIC_API_URL to your reachable API address
npx expo start
```
Press `w` for web, or scan the QR code using Expo Go. For an Android store build, configure EAS and create a release build.

### Database update
The new social and TIME features add a Prisma migration under `server/prisma/migrations/20261121000000_social_time_features`. Apply it to the existing database before starting the updated API:

```bash
cd server
npx prisma migrate deploy
npx prisma generate
```

### Website
Set the API's public HTTPS address in `website/config.js` (`window.GAMETIME_API_URL`) and publish the contents of `website/` to a static host. Add the website origin to `CLIENT_ORIGIN` on the API. The Expo web client can also be exported separately from `client/`.

## Important production work before publishing
This is an updated MVP source package, not a deployed production service and not yet a signed store package. The new database migration must be applied before using the new endpoints.
Before public release:
1. Deploy API and PostgreSQL to a reliable provider; use HTTPS.
2. Set strong secrets and configure allowed origins.
3. Add email/phone verification, password reset, rate limits, abuse reporting and moderation.
4. Complete privacy policy, terms, support contact and data deletion process.
5. Add admin account provisioning securely (never expose admin registration publicly).
6. Test on real Android devices and web browsers.
7. Review current Cafe Bazaar developer requirements and submit the signed Android build for review. Acceptance cannot be guaranteed.

## Timer integrity
Online sessions are timestamped by the API. If the device is offline, the app stores the active timer and completed session locally, then synchronizes queued sessions when a connection returns. Synced offline sessions are validated for positive duration and capped at 24 hours per session. Because offline timestamps originate on the device, they are less tamper-resistant than online sessions.

## Environment variables
Use `server/.env.example` for local API setup and copy `.env.production.example` to `.env` on the production host. Configure `EXPO_PUBLIC_API_URL` and `EXPO_PUBLIC_WEBSITE_URL` for the mobile client. Set `website/config.js` before publishing the web portal.


## Deployment package (v4)
- `docker-compose.yml` and `server/Dockerfile` for API + PostgreSQL deployment
- `.env.production.example` for server secrets
- `client/eas.json` for preview APK and production AAB build profiles
- `DEPLOYMENT_FA.md` for deployment and store-build steps
- `RELEASE_CHECKLIST_FA.md` for manual release testing

The project is not yet deployed and has not passed load testing or store review.
